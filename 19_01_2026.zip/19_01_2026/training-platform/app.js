const express = require('express');
const app = express();

const courseController = require('./controllers/courseController');

app.use(express.json());

// HOME ROUTE
app.get('/', (req, res) => {
  res.send('Training Platform API Running');
});

// COURSE ROUTES
app.post('/courses', courseController.createCourse);
app.get('/courses', courseController.getCourses);
app.get('/courses/:id', courseController.getCourseById);
app.put('/courses/:id', courseController.updateCourse);
app.delete('/courses/:id', courseController.deleteCourse);

module.exports = app;
